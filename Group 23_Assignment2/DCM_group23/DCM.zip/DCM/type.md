mode : uint8
LRL : uint8
MSR : uint8
ARP : uint16
VRP : uint16
ATR_AMP : single
VENT_AMP : single

